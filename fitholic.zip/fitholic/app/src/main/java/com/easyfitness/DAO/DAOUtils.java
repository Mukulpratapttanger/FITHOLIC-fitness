package com.easyfitness.DAO;


public class DAOUtils {

    public static final String DATE_FORMAT = "yyyy-MM-dd";

}
